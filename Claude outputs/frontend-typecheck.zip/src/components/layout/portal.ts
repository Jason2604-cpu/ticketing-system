import type { Role } from '../../types'

export type Portal = 'admin' | 'engineer' | 'client'
export const portalFor = (role?: Role): Portal => (role === 'ADMIN' ? 'admin' : role === 'ENGINEER' ? 'engineer' : 'client')
