# Dev scripts

- `dev.bat` — starts the backend (`mvnw.cmd spring-boot:run`, port 8080) and the
  frontend (`npm run dev`, port 5173) each in their own window. Double-click it,
  or run it from a terminal at the project root.
- `stop.bat` — closes the two windows `dev.bat` opened.

Requires `backend\.env` to already be set up (DB, mail, etc.) — this just launches
the two dev servers, it doesn't configure anything.

# Server scripts (Linux Docker host)

- `install-docker-host.sh` — installs Docker Engine, Compose v2, Buildx, git and openssl on
  Ubuntu/Debian: `sudo bash scripts/install-docker-host.sh`. See DEPLOYMENT.md step 2.
- `backup.sh` — dumps the database and the uploaded media into `backups/<timestamp>/`
  (keeps 14). Run from the project folder: `bash scripts/backup.sh`.
