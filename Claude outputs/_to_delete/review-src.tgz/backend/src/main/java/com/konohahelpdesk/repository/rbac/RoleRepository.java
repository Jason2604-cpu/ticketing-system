package com.konohahelpdesk.repository.rbac;

import com.konohahelpdesk.model.rbac.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(String name);
    boolean existsByNameIgnoreCase(String name);
    List<Role> findAllByOrderByNameAsc();
    /** Just the names — what RoleSeeder needs, without loading every role's privilege set. */
    @org.springframework.data.jpa.repository.Query("select r.name from Role r")
    java.util.List<String> findAllNames();
}
