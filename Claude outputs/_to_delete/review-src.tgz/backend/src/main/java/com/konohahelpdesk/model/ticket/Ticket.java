package com.konohahelpdesk.model.ticket;

import com.konohahelpdesk.model.company.Company;
import com.konohahelpdesk.model.user.User;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
// Schema is owned by Flyway (db/migration). These @Index entries mirror it for readability;
// the partial / expression indexes (open-by-company, finished-at) exist only in V2.
@Table(name = "tickets", indexes = {
        @Index(name = "ix_tickets_company_created", columnList = "company_id, created_at"),
        @Index(name = "ix_tickets_status", columnList = "status"),
        @Index(name = "ix_tickets_assignee", columnList = "assignee_id"),
        @Index(name = "ix_tickets_created", columnList = "created_at")
})
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(name = "steps_to_reproduce", columnDefinition = "TEXT")
    private String stepsToReproduce;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TicketCategory category = TicketCategory.TECHNICAL;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TicketPriority priority = TicketPriority.MEDIUM;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TicketStatus status = TicketStatus.OPEN;

    @ManyToOne(optional = false)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(optional = false)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @ManyToOne
    @JoinColumn(name = "assignee_id")
    private User assignee;

    // SLA targets computed at creation from the company's subscription
    @Column(name = "response_due_at") private LocalDateTime responseDueAt;
    @Column(name = "resolution_due_at") private LocalDateTime resolutionDueAt;
    @Column(name = "first_response_at") private LocalDateTime firstResponseAt;
    // Stamped by SlaMonitor the first time a deadline is found blown, so each breach
    // escalates exactly once and reporting can filter on it without recomputing.
    @Column(name = "response_breached_at") private LocalDateTime responseBreachedAt;
    @Column(name = "resolution_breached_at") private LocalDateTime resolutionBreachedAt;
    @Column(name = "resolved_at") private LocalDateTime resolvedAt;
    @Column(name = "closed_at") private LocalDateTime closedAt;

    @Column(name = "created_at", updatable = false, nullable = false)
    private LocalDateTime createdAt;
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now(); updatedAt = createdAt; }

    @PreUpdate
    protected void onUpdate() { updatedAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getStepsToReproduce() { return stepsToReproduce; }
    public void setStepsToReproduce(String stepsToReproduce) { this.stepsToReproduce = stepsToReproduce; }
    public TicketCategory getCategory() { return category; }
    public void setCategory(TicketCategory category) { this.category = category; }
    public TicketPriority getPriority() { return priority; }
    public void setPriority(TicketPriority priority) { this.priority = priority; }
    public TicketStatus getStatus() { return status; }
    public void setStatus(TicketStatus status) { this.status = status; }
    public Company getCompany() { return company; }
    public void setCompany(Company company) { this.company = company; }
    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }
    public User getAssignee() { return assignee; }
    public void setAssignee(User assignee) { this.assignee = assignee; }
    public LocalDateTime getResponseDueAt() { return responseDueAt; }
    public void setResponseDueAt(LocalDateTime v) { this.responseDueAt = v; }
    public LocalDateTime getResolutionDueAt() { return resolutionDueAt; }
    public void setResolutionDueAt(LocalDateTime v) { this.resolutionDueAt = v; }
    public LocalDateTime getFirstResponseAt() { return firstResponseAt; }
    public void setFirstResponseAt(LocalDateTime v) { this.firstResponseAt = v; }
    public LocalDateTime getResponseBreachedAt() { return responseBreachedAt; }
    public void setResponseBreachedAt(LocalDateTime v) { this.responseBreachedAt = v; }
    public LocalDateTime getResolutionBreachedAt() { return resolutionBreachedAt; }
    public void setResolutionBreachedAt(LocalDateTime v) { this.resolutionBreachedAt = v; }
    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime v) { this.resolvedAt = v; }
    public LocalDateTime getClosedAt() { return closedAt; }
    public void setClosedAt(LocalDateTime v) { this.closedAt = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
