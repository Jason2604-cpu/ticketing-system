package com.konohahelpdesk.security;

import com.konohahelpdesk.config.AppProperties;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import com.konohahelpdesk.store.RateLimitStore;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;

/**
 * Per-IP fixed-window rate limiter.
 *
 * Two buckets: a general one for every /api/** request and a much stricter one
 * for the anonymous auth endpoints (login, activate, forgot/reset password —
 * brute force and token guessing). Limits come from app.security.rate-limit.*.
 *
 * The counters live in a {@link RateLimitStore}: in memory by default, Redis when
 * app.store.type=redis, so limits hold across several backend containers.
 *
 * Behind the nginx container, set TRUST_FORWARDED_FOR=true so the limit is per real client rather
 * than per nginx. nginx overwrites X-Forwarded-For with $remote_addr, so a client can't spoof it.
 */
public class RateLimitFilter extends OncePerRequestFilter {

    private static final Duration WINDOW = Duration.ofMinutes(1);

    private final AppProperties.RateLimit cfg;
    /** Routed through the bean rather than a bare slf4j logger so rejections reach the audit viewer. */
    private final AuditLogger auditLogger;
    private final RateLimitStore store;

    public RateLimitFilter(AppProperties props, AuditLogger auditLogger, RateLimitStore store) {
        this.cfg = props.getSecurity().getRateLimit();
        this.auditLogger = auditLogger;
        this.store = store;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return !cfg.isEnabled() || !request.getRequestURI().startsWith("/api/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String ip = clientIp(request);
        String uri = request.getRequestURI();
        boolean isSensitive = "POST".equalsIgnoreCase(request.getMethod())
                && (uri.equals("/api/auth/login") || uri.equals("/api/auth/activate")
                    || uri.equals("/api/auth/forgot-password") || uri.equals("/api/auth/reset-password"));

        if (isSensitive && store.hitAndCheckExceeded("auth", ip, cfg.getLoginAttemptsPerMinute(), WINDOW)) {
            auditLogger.warn("RATE_LIMIT", "scope=auth ip=" + ip + " uri=" + uri);
            reject(response);
            return;
        }
        if (store.hitAndCheckExceeded("api", ip, cfg.getRequestsPerMinute(), WINDOW)) {
            auditLogger.warn("RATE_LIMIT", "scope=api ip=" + ip + " uri=" + uri);
            reject(response);
            return;
        }

        chain.doFilter(request, response);
    }

    private void reject(HttpServletResponse response) throws IOException {
        response.setStatus(429);
        response.setHeader("Retry-After", "60");
        response.setContentType("application/json");
        response.getWriter().write("{\"timestamp\":\"" + Instant.now()
            + "\",\"status\":429,\"error\":\"Too many requests. Please try again shortly.\"}");
    }

    private String clientIp(HttpServletRequest request) {
        if (cfg.isTrustForwardedFor()) {
            String xff = request.getHeader("X-Forwarded-For");
            if (xff != null && !xff.isBlank()) {
                return xff.split(",")[0].trim();
            }
        }
        return request.getRemoteAddr();
    }
}
